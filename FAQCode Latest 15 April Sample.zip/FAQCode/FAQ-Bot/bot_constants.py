"""
Constants available in BOT
"""

def all_banks():
    """
    All Available Bank codes
    """
    current_bank_codes = ["FED", "SIB", "SBI"]
    return current_bank_codes

def data_layer_connection_string():
    """
    function to set the connection string
    """
    #config = bot_constants.data_layer_connection_string()
    #cnx = db.connect(**config)
    config = {'user': 'sa', 'password': 'Silicon123123', 'host': '127.0.0.1'\
    , 'database': 'chatbot', 'raise_on_warnings': True}
    return config
