CREATE DATABASE `chatbot` /*!40100 DEFAULT CHARACTER SET utf8 */;

use chatbot;

CREATE TABLE user ( user_id int NOT NULL AUTO_INCREMENT,
					user_name NVARCHAR(250) NOT NULL,
                    user_password NVARCHAR(500) NOT NULL,
                    access_token NVARCHAR(1000) NULL,
                    first_name nvarchar(300) NULL,
                    last_name nvarchar(800) NULL,
                    created_date datetime NULL ,
                    last_login datetime NULL ,
                    last_logout datetime NULL ,
                    is_active boolean default 1,
                    PRIMARY KEY (user_id),
                    UNIQUE KEY (user_name));
                    
INSERT INTO user (user_name,user_password,access_token,first_name,last_name,created_date,last_login,last_logout
						) 
                        VALUES
                        ("reshma@gmail.com","5d41402abc4b2a76b9719d911017c592","5d41402abc4b2a76b9719d911017c592",
                        "Reshma","Thomas",NOW(),NOW(),NOW())
                    

create table user_logs ( log_id int NOT NULL AUTO_INCREMENT,
						 user_id int NULL,
                         access_token nvarchar(3000)  NULL,
						 log_date datetime  NULL,
                         user_request TEXT  NULL,
                         generated_intent NVARCHAR(500)  NULL,
                         generated_intent_confidence NVARCHAR(500)  NULL,
                         generated_response TEXT  NULL,
                         PRIMARY KEY (log_id)
                         );

