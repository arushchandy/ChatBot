"""
Functions used in classifying the input text as per intent.
"""

import pickle

def find_intent(input_text):
    """
    function to find the intent from the input text.
    """
    with open('TrainingModel\\naivemodel.pkl', 'rb') as pkl_file:
        naive_classifier = pickle.load(pkl_file)
        pkl_file.close()
        prob_dist = naive_classifier.prob_classify(input_text)
    print prob_dist
    confidence = round(prob_dist.prob(prob_dist.max()), 2)
    most_probable_intent = prob_dist.max()
    print confidence, most_probable_intent
    return (most_probable_intent, confidence)


