"""
File to handle data access from mysql server
connection string given in bot_constant file.
"""
import hashlib
import base64
import uuid
import bot_constants
import mysql.connector as db



def user_login(user_name, user_password):
    """
    function to check user aunthenticity
    """
    #print "hello"
    result_data = {"status" : "Fail", "code" : 404}
    config = bot_constants.data_layer_connection_string()
    cnx = db.connect(**config)
    cursor = cnx.cursor()
    password = hashlib.md5(user_password).hexdigest()
    #query = "SELECT user_name FROM user WHERE user_name = ? and user_passwprd = ?"
    access_token = get_a_uuid()

    cursor.execute(" SELECT user_id,first_name,last_name FROM user WHERE \
    user_name = %s and user_password = %s ", (user_name, password))
    for (user_id, first_name, last_name) in cursor:
        print user_name
        result_data = {"status" : "Success", "code" : 200, "id":user_id \
        , "access_token": access_token, "first_name":first_name \
        , "last_name":last_name}
        cursor.execute(" UPDATE user SET access_token = %s WHERE \
        user_name = %s and user_id = %s ", (access_token, user_name, user_id))
    cursor.close()
    cnx.commit()
    cnx.close()
    return result_data

def create_user(user_name, user_password, f_name, l_name):
    """
    function to insert a new user into the database
    """
    user_name_exists = check_username(user_name)
    is_success = {}
    if  user_name_exists:
        print "name still available"
        is_success = {"result" : "Fail", "code":400}
    else:
        print "name exists"
        config = bot_constants.data_layer_connection_string()
        cnx = db.connect(**config)
        cursor = cnx.cursor()
        password = hashlib.md5(user_password).hexdigest()
        access_token = get_a_uuid()
        cursor.execute(" INSERT INTO user (user_name,user_password,access_token,  \
        first_name,last_name,created_date,last_login,last_logout ) VALUES \
        (%s, %s, %s, %s, %s,NOW(),NOW(),NOW())", (user_name, password, \
        access_token, f_name, l_name))
        cursor.close()
        cnx.commit()
        cnx.close()
        is_success = user_login(user_name, user_password)
    return is_success


def check_username(user_name):
    """
    function to check if only the user_name is existing in the db.
    """
    user_name_exists = False
    config = bot_constants.data_layer_connection_string()
    cnx = db.connect(**config)
    cursor = cnx.cursor()
    #query = "SELECT user_name FROM user WHERE user_name = ? and user_passwprd = ?"

    cursor.execute(" SELECT user_name FROM user WHERE \
    user_name = %s ", (user_name, ))

    for user_name in cursor:
        user_name_exists = True
        print "User Name Exists"

    cursor.close()
    cnx.close()
    return user_name_exists

def get_a_uuid():
    """"
    To get a uuid for the access token to be set in db
    """
    r_uuid = base64.urlsafe_b64encode(uuid.uuid4().bytes)
    return r_uuid.replace('=', '')

def save_user_resquest_tolog(user_id, user_request, access_token, intent_code, response_data, confidence):
    """
    Save to log db
    user_id int , access_token,log_date datetime,user_request,
    generated_intent,generated_intent_confidence,generated_response
    """
    print "Saving response to log"
    config = bot_constants.data_layer_connection_string()
    cnx = db.connect(**config)
    cursor = cnx.cursor()
    print cursor
    cursor.execute(" INSERT INTO user_logs (user_id, user_request,access_token,log_date,  \
    generated_intent,generated_response,generated_intent_confidence) VALUES \
    (%s,%s,%s,NOW(), %s, %s, %s)", (user_id, user_request, access_token, \
    intent_code, response_data, confidence))
    cursor.close()
    cnx.commit()
    cnx.close()

"""
if __name__ == "__main__":
    user_login("reshma@gmail.com", "hello")
    create_user("reshm1a@gmail.com", "hello", "Reshma", "Thomas")
"""
