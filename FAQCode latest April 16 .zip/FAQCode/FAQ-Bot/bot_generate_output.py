

def find_output_type(most_probable_intent, confidence):
    """
    class to identiyfy the intent type
    """
    # classes are INF with format INF-NON for common responses
    # UKN for unknown responses
    # COM for comparing data
    # INF for retreving information
    # if confidence > .5 the format id class-bank-intent
    # example INF-FED-FDINFO means class INF bank FEDERAL BANK FDINFO intent

    if confidence < .5 and confidence > .3:
        class_indent = "UKN"
        indent_return = "LOW"
        intent_bank = "NON"
    elif  confidence <= .3:
        class_indent = "UKN"
        indent_return = "TOOLOW"
        intent_bank = "NON"
    else:
        intent_data = most_probable_intent.split("-")
        class_indent = intent_data[0]
        indent_return = intent_data[2]
        intent_bank = intent_data[1]
    return (class_indent, intent_bank, indent_return)

