""""
Server for chat bot.
"""
from json import dumps
import bot_training as training
import bot_classify
import bot_create_response
import bot_generate_output
import bot_dataaccesslayer as dal
from flask import Flask, request
from flask_cors import CORS, cross_origin



appl = Flask(__name__)
cors = CORS(appl)
appl.config['CORS_HEADERS'] = 'Content-Type'

#Initialization starts
#configParser=ConfigParser.RawConfigParser()
#confighParser.read(configFilePath)
#Host=configParser.get('file','host')
#Port=configParser.get('file','port')

#Config read ends
# @appl.hook('after_request')
# def enable_cors():
# # set CORS headers
#     print "hello"
#     response.headers['Access-Control-Allow-Origin'] = '*'
#     response.headers['Access-Control-Allow-Methods'] = '*'
#     response.headers['Access-Control-Allow-Headers'] = '*'


@appl.route('/cors', methods=['OPTIONS', 'GET'])
def lvambience():
    """
    test
    """
    #response.headers['Content-type'] = 'application/json'
    return '[1]'


@appl.route('/trainBot', methods=['GET'])
def trainbot():
    """
    trainbot function used to train the model using the available dataset provided in train.csv
    Args: null
    Return : Status of training on available data set
    """
    #response.content_type = 'application/json'
    return_data = training.dobottraining()
    return dumps(return_data)


@appl.route('/userrequest', methods=['POST'])
@cross_origin()
def parse_user_request():
    """
    Function used to read the user input and then
    based on classified class from model return data to user
    """
    #response.content_type = 'application/json'
    input_text = request.json["input-request"]
    user_id = request.json["user_id"]
    access_token = request.json["access_token"]
    (most_probable_intent, confidence) = bot_classify.find_intent(input_text)
    (class_indent, intent_bank, indent_return) = bot_generate_output.find_output_type \
    (most_probable_intent, confidence)
    classsified_response = bot_create_response.generate_response(class_indent, \
    intent_bank, indent_return)
    #print user_id, access_token, most_probable_intent, classsified_response, confidence
    response_value = dumps(classsified_response)
    dal.save_user_resquest_tolog(user_id, input_text, access_token, \
    most_probable_intent, response_value, confidence)
    return response_value

@appl.route('/login', methods=['POST'])
@cross_origin()
def parse_login():
    """
    Function used to read the user input and then
    based on classified class from model return data to user
    """
    #response.content_type = 'application/json'
    user_name = request.json["user_name"]
    user_password = request.json["user_password"]
    print user_name, user_password
    result = dal.user_login(user_name, user_password)
    return dumps(result)


@appl.route('/createuser', methods=['POST'])
@cross_origin()
def create_user():
    """
    Function used to read the user input and then
    based on classified class from model return data to user
    """
    #response.content_type = 'application/json'
    user_name = request.json["user_name"]
    user_password = request.json["user_password"]
    first_name = request.json["first_name"]
    last_name = request.json["last_name"]
    print user_name, user_password
    result = dal.create_user(user_name, user_password, first_name, last_name)
    return dumps(result)


if __name__ == '__main__':
    #appl.run(host='localhost',port=8000)
    appl.run(host='localhost', processes=True, debug=True, port=8000)

