"use strict";

/// <reference path="jquery-1.12.4.min.js" />
var serverurl = "http://localhost:8000"
//var serverurl = "http://127.0.0.1:8000"

var signup = function(){
     // signup_first_name signup_last_name signup_password signup_reenterpassword
    var signup_user_id = $("#signup_user_id").val();
    var signup_password = $("#signup_password").val();
    var signup_reenterpassword = $("#signup_reenterpassword").val();
    var signup_first_name = $("#signup_first_name").val();
    var signup_last_name = $("#signup_last_name").val();
    if (signup_user_id != "" && signup_password != "" && signup_password == signup_reenterpassword && signup_first_name != "" && signup_last_name != "") {
       create_user(signup_user_id,signup_password,signup_first_name,signup_last_name);
    }
};

var signin = function(){
      var user_id = $("#userid").val();
      var password = $("#passwordinput").val();
    if (user_id != "" && password != "") {
       check_login(user_id,password);
    }
};

var create_user = function(signup_user_id,signup_password,signup_first_name,signup_last_name){
    var data_tosend = { "user_name": signup_user_id , "user_password" : signup_password , "first_name" : signup_first_name , "last_name" : signup_last_name };
     $.ajax({
            url: serverurl + "/createuser",
            method: "POST",
            type: "POST",
            data: JSON.stringify(data_tosend),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (result) {
            //alert("here")
            add_login_data_toLocalstore(result);
            }
        });
};


var check_login = function (user_name,password) {
    var data_tosend = { "user_name": user_name , "user_password" : password };
    $.ajax({
        url: serverurl + "/login",
        method: "POST",
        type: "POST",
        data: JSON.stringify(data_tosend),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (result) {
           //alert("here")
           add_login_data_toLocalstore(result);
        }
    });
}

var add_login_data_toLocalstore = function(data){
  if (data != undefined && data.code == 200) {
  //alert("yes");
  localStorage.setItem("access-token",data.access_token);
  localStorage.setItem("id",data.id);
  localStorage.setItem("first_name",data.first_name);
  localStorage.setItem("last_name",data.last_name);
  window.location.href = '/FAQBot.html';
} else{
    alert("Sorry data are wrong !")
}
};

