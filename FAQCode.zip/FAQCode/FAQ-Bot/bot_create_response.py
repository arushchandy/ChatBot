import json
import pickle
import bot_constants


def generate_response(class_indent, intent_bank, indent_return):
    """
    get response from json file using the classified value
    """
    return_data = {}
    if class_indent == "COM":
        #compare class so need to compare all files for values
        (intent_bank) = compare_all_files(indent_return)
    file_name = 'Response\\' + class_indent + '-' + intent_bank + '-output.json'
    with open(file_name, 'r') as data_file:
        data = json.load(data_file)
        return_data = data[indent_return]
        print return_data
    return return_data

def compare_all_files(intent):
    """
    need to compare all banks data for current intent
    """
    result_bank = ""
    available_banks = bot_constants.all_banks()
    bank_count = 0
    compare_values = []
    is_ascending = True
    intent_value = 0
    intent_data = ""
    previous = 0
    total_bank = 0
    for bank in available_banks:
        total_bank += 1
        file_name = 'Response\\COM-' + bank + '-output.json'
        with open(file_name, 'r') as data_file:
            data = json.load(data_file)
            intent_data = data[intent]["order"]
            intent_value = data[intent]["value"]
            if intent_data != "ASC":
                is_ascending = False
            compare_values.append(intent_value)
    for compare_value in compare_values:
        if is_ascending:
            if previous != 0:
                bank_count += 0 if previous > float(compare_value) else 1
                previous = previous if previous > float(compare_value) else float(compare_value)
        elif previous != 0:
            bank_count += 0 if previous < float(compare_value) else 1
            previous = previous if previous < float(compare_value) else float(compare_value)
        print total_bank
        result_bank = available_banks[bank_count-1]
    return result_bank
